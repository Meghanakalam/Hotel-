from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def reservation_form():
    myname = "Meghana Kalam"
    return render_template('reservation_form.html', myname=myname)


@app.route('/reserve', methods=['POST'])
def reserve():
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    email = request.form['email']
    room_type = request.form['room_type']
    stay_days = request.form['stay_days']
    myname = "Meghana Kalam"
    room_type = room_type.lower()
    if room_type == 'queen':
        room_price = 200
    elif room_type == 'king':
        room_price = 300
    else:
        room_price = 400
    total_price = int(room_price)*int(stay_days)
    room_type = room_type.capitalize()
    # Process the form data and save the reservation
    return render_template('reserve.html', first_name=first_name, last_name=last_name, myname=myname, room_type=room_type, total_price=total_price, num_days=stay_days, email=email)



if __name__ == '__main__':
    app.run(port=5537)
